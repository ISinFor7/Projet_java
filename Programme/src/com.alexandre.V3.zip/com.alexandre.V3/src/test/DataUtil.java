package test;


import java.util.Arrays;

import modele.Album;
import modele.Artiste;
import modele.Bibliotheque;
import modele.Chanson;

public class DataUtil {
    public static Bibliotheque createTestBibliotheque() {
        Chanson chanson1 = new Chanson();
        chanson1.setTitre("Chanson 1");
        chanson1.setDuree("3:45");

        Album album1 = new Album();
        album1.setTitre("Album 1");
        album1.setAnnee(2020);
        album1.setChansons(Arrays.asList(chanson1));

        Artiste artiste1 = new Artiste();
        artiste1.setNom("Artiste 1");
        artiste1.setAlbums(Arrays.asList(album1));

        Bibliotheque bibliotheque = new Bibliotheque();
        bibliotheque.setArtistes(Arrays.asList(artiste1));

        return bibliotheque;
    }
}
