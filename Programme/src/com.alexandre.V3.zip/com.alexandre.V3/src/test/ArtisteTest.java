package test;


import modele.Album;
import modele.Artiste;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;

public class ArtisteTest {
    @Test
    public void testArtisteCreation() {
        Album album1 = new Album();
        album1.setTitre("Album 1");
        album1.setAnnee(2020);

        Artiste artiste = new Artiste();
        artiste.setNom("Artiste 1");
        artiste.setAlbums(Arrays.asList(album1));

        assertEquals("Artiste 1", artiste.getNom());
        assertEquals(1, artiste.getAlbums().size());
        assertEquals("Album 1", artiste.getAlbums().get(0).getTitre());
    }
}
