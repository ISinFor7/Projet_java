package test;


import org.junit.Test;

import vue.BibliothequeView;

import static org.junit.Assert.*;

public class BibliothequeViewTest {
    @Test
    public void testViewComponents() {
        BibliothequeView view = new BibliothequeView();

        assertNotNull(view.getSearchQuery());
        assertNotNull(view.getResults());
    }

    @Test
    public void testSetAndGetResults() {
        BibliothequeView view = new BibliothequeView();
        String expectedResults = "Test results";
        view.setResults(expectedResults);

        assertEquals(expectedResults, view.getResults());
    }
}

