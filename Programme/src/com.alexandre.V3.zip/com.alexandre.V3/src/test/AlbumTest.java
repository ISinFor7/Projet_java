package test;


import org.junit.Test;

import modele.Album;
import modele.Chanson;

import static org.junit.Assert.*;

import java.util.Arrays;

public class AlbumTest {
    @Test
    public void testAlbumCreation() {
        Chanson chanson1 = new Chanson();
        chanson1.setTitre("Chanson 1");
        chanson1.setDuree("3:45");

        Chanson chanson2 = new Chanson();
        chanson2.setTitre("Chanson 2");
        chanson2.setDuree("4:20");

        Album album = new Album();
        album.setTitre("Album 1");
        album.setAnnee(2020);
        album.setChansons(Arrays.asList(chanson1, chanson2));

        assertEquals("Album 1", album.getTitre());
        assertEquals(2020, album.getAnnee());
        assertEquals(2, album.getChansons().size());
        assertEquals("Chanson 1", album.getChansons().get(0).getTitre());
    }
}

