package test;

import modele.*;
import vue.BibliothequeView;

import org.junit.Before;
import org.junit.Test;

import controleur.BibliothequeController;

import static org.junit.Assert.*;



public class BibliothequeControllerTest {
    private Bibliotheque model;
    private BibliothequeView view;
    private BibliothequeController controller;

    @Before
    public void setUp() {
        model = BibliothequeController.chargerBibliotheque("src\\BDD\\bdd.json");
        view = new BibliothequeView();
        controller = new BibliothequeController(model, view);
    }

    @Test
    public void testRechercheArtiste() {
        Artiste foundArtiste = controller.rechercherArtiste("Drake");
        assertNotNull(foundArtiste);
        assertEquals("Drake", foundArtiste.getNom());
    }

    @Test
    public void testRechercheArtisteNonExistant() {
        Artiste foundArtiste = controller.rechercherArtiste("Artiste Inconnu");
        assertNull(foundArtiste);
    }

    @Test
    public void testSearchListener() {
        view.setResults("");
        view.getSearchField().setText("Drake");
        view.getSearchButton().doClick();

        String expectedResults = "Artiste: Drake\n" +
                "  Album: For All The Dogs Scary Hours Edition (2023)\n" +
                "    Chanson: Virginia Beach (251)\n" +
                "    Chanson: Amen (feat. Teezo Touchdown) (141)\n" +
                "    Chanson: Calling For You (feat. 21 Savage) (285)\n" +
                "    Chanson: Evil Ways (feat. J. Cole) (227)\n";
        assertEquals(expectedResults, view.getResults());
    }
}
