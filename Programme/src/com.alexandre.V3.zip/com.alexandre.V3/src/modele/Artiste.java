package modele;


import java.util.List;

public class Artiste {
    private String nom;
    private List<Album> albums;

    // Constructeur par défaut
    public Artiste() {}

    // Constructeur avec paramètres
    public Artiste(String nom, List<Album> albums) {
        this.nom = nom;
        this.albums = albums;
    }

    // Getters et Setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public List<Album> getAlbums() {
        return albums;
    }

    public void setAlbums(List<Album> albums) {
        this.albums = albums;
    }

    @Override
    public String toString() {
        return "Artiste{" +
                "nom='" + nom + '\'' +
                ", albums=" + albums +
                '}';
    }
}
