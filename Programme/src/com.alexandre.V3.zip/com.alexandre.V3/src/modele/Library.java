package modele;

import java.util.List;


public class Library {
    private List<Artiste> artistes;

    public List<Artiste> getArtistes() {
        return artistes;
    }

    public void setArtistes(List<Artiste> artistes) {
        this.artistes = artistes;
    }
}