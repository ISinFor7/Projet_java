package modele;


import java.util.List;

public class Bibliotheque {
    private List<Artiste> artistes;

    // Getters et Setters
    public List<Artiste> getArtistes() {
        return artistes;
    }

    public void setArtistes(List<Artiste> artistes) {
        this.artistes = artistes;
    }
}
