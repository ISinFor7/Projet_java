package vue;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;


public class BibliothequeView extends JFrame {
    private JTextField searchField;
    private JButton searchButton;
    private JTextArea resultArea;

    public BibliothequeView() {
        // Configuration de la fenêtre
        setTitle("Bibliothèque Musicale");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Création des composants
        searchField = new JTextField(30);
        searchButton = new JButton("Rechercher");
        resultArea = new JTextArea();
        resultArea.setEditable(false);

        // Organisation des composants
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(new JLabel("Rechercher:"));
        panel.add(searchField);
        panel.add(searchButton);

        // Ajout des composants à la fenêtre
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    public String getSearchQuery() {
        return searchField.getText();
    }

    public void setResults(String results) {
        resultArea.setText(results);
    }

    public String getResults() {
        return resultArea.getText();
    }

    public void addSearchListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JButton getSearchButton() {
        return searchButton;
    }
}
