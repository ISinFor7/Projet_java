package vue;




import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import modele.Album;
import modele.Artiste;
import modele.Chanson;
import modele.Library;

import java.util.List;

import BDD.DataParser;


public class LibraryApp extends Application {
    private List<Artiste> artistes;

    @Override
    public void start(Stage primaryStage) {
        Library library = DataParser.parseJson("src\\BDD\\bdd.json");
        if (library != null) {
            artistes = library.getArtistes();
        }

        BorderPane root = new BorderPane();
        ListView<String> listView = new ListView<>();

        for (Artiste artiste : artistes) {
            listView.getItems().add(artiste.getNom());
        }

        listView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            for (Artiste artiste : artistes) {
                if (artiste.getNom().equals(newValue)) {
                    showArtistDetails(artiste);
                    break;
                }
            }
        });

        root.setCenter(listView);
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Music Library");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showArtistDetails(Artiste artiste) {
        Stage detailStage = new Stage();
        BorderPane detailPane = new BorderPane();
        ListView<String> albumList = new ListView<>();

        for (Album album : artiste.getAlbums()) {
            albumList.getItems().add(album.getNom());
        }

        albumList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            for (Album album : artiste.getAlbums()) {
                if (album.getNom().equals(newValue)) {
                    showAlbumDetails(album);
                    break;
                }
            }
        });

        detailPane.setCenter(albumList);
        Scene detailScene = new Scene(detailPane, 400, 400);
        detailStage.setTitle(artiste.getNom());
        detailStage.setScene(detailScene);
        detailStage.show();
    }

    private void showAlbumDetails(Album album) {
        Stage albumStage = new Stage();
        BorderPane albumPane = new BorderPane();
        ListView<String> songList = new ListView<>();

        for (Chanson chanson : album.getChansons()) {
            songList.getItems().add(chanson.getTitre() + " (" + chanson.getDuree() + "s)");
        }

        albumPane.setCenter(songList);
        Scene albumScene = new Scene(albumPane, 400, 400);
        albumStage.setTitle(album.getNom());
        albumStage.setScene(albumScene);
        albumStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
