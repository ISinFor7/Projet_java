package BDD;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import modele.Artiste;
import modele.Library;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;



public class DataParser {
    public static Library parseJson(String filePath) {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(filePath)) {
            return gson.fromJson(reader, Library.class);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
