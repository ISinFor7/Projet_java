package DB;

import org.json.simple.JSONObject;

public class Main {
    public static void main(String[] args) {
        Controleur controleur = new Controleur();




        controleur.creerNouvelUtilisateur();


        
    }
}